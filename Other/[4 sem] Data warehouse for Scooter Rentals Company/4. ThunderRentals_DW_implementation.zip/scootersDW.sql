CREATE DATABASE scootersDW;

USE scootersDW;


CREATE TABLE "Areas [DT]" (
   "area_ID" INTEGER PRIMARY KEY,
   "Name" NVARCHAR(50) NOT NULL,
   "City" NVARCHAR(50) NOT NULL,
);

CREATE TABLE "Scooters [DT]" (
   "scooter_ID" INTEGER PRIMARY KEY,
   "SerialNumber" NUMERIC NOT NULL,
   "Model" NVARCHAR(10) NOT NULL,
   "Producer" NVARCHAR(15) NOT NULL,
);

CREATE TABLE "Customers [DT]" (
   Customer_ID INTEGER PRIMARY KEY,
   PhoneNumber NVARCHAR(13) NOT NULL,
   NameSurname NVARCHAR(65) NOT NULL,
   EmailAddress NVARCHAR(50) NOT NULL,
   DateOfBirth DATE NOT NULL,
   Gender VARCHAR(9) NOT NULL,
   AgeCategory VARCHAR(6) NOT NULL,
   IsCurrent BIT NOT NULL,
);

CREATE TABLE "ScooterState [DT]" (
   state_ID INTEGER PRIMARY KEY,
   area_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Areas [DT]"("area_ID"),
   BatteryCategory VARCHAR(8) NOT NULL,
   "Status" VARCHAR(7) NOT NULL,
   ExpectedTravelDistanceCategory VARCHAR(8) NOT NULL,
);

CREATE TABLE "Date [DT]" (
   "date_ID" INTEGER PRIMARY KEY,
   "Date" DATE NOT NULL,
   "Year" VARCHAR(4) NOT NULL,
   "Month" VARCHAR(10) NOT NULL,
   "MonthNo" NUMERIC NOT NULL,
   "DayOfWeek" VARCHAR(10) NOT NULL,
   "DayOfWeekNo" NUMERIC NOT NULL,
   "DayOfMonthNo" NUMERIC NOT NULL,
   "HolidaySeason" VARCHAR(3) NOT NULL,
);

CREATE TABLE "Time [DT]" (
   "Time_ID" INTEGER PRIMARY KEY,
   "Timezone" VARCHAR(7) NOT NULL,
   "Hour12" VARCHAR(3) NOT NULL,
   "AmPm" VARCHAR(3) NOT NULL,
   "Hour24" NUMERIC NOT NULL,
   "Minute" NUMERIC NOT NULL,
   "Second" NUMERIC NOT NULL,
);

CREATE TABLE "Junk [DT]" (
   "junk_ID" INTEGER PRIMARY KEY,
   "Problem" VARCHAR(3) NOT NULL,
);

CREATE TABLE "Rentals [FT]" (
   scooter_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Scooters [DT]"("Scooter_ID"),
   start_state_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "ScooterState [DT]"("state_ID"),
   end_state_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "ScooterState [DT]"("state_ID"),
   customer_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Customers [DT]"("Customer_ID"),
   start_date_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Date [DT]"("Date_ID"),
   start_time_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Time [DT]"("Time_ID"),
   end_date_ID INTEGER FOREIGN KEY REFERENCES "Date [DT]"("Date_ID"),
   end_time_ID INTEGER FOREIGN KEY REFERENCES "Time [DT]"("Time_ID"),
   junk_ID INTEGER NOT NULL FOREIGN KEY REFERENCES "Junk [DT]"("Junk_ID"),
   CustomerPhoneNumber NVARCHAR(13) NOT NULL,
   TravelledDistance INTEGER NOT NULL,
   DurationSeconds INTEGER NOT NULL,
   UserAge INTEGER NOT NULL,
   startBatteryPercentage INTEGER NOT NULL,
   endBatteryPercentage INTEGER NOT NULL,
   expectedStartDistance INTEGER NOT NULL,
   expectedEndDistance INTEGER NOT NULL
);