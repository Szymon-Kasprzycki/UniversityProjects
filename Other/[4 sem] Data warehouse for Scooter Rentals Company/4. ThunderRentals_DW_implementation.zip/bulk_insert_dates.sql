USE scootersDW;

BULK INSERT [Date [DT]]] FROM 'D:\Studia\4sem\Data Warehouses\task4\dates.csv' WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', DATAFILETYPE = 'char');

BULK INSERT [Time [DT]]] FROM 'D:\Studia\4sem\Data Warehouses\task4\seconds_in_day.csv' WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', DATAFILETYPE = 'char');


BULK INSERT [Customers [DT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\customers.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');


BULK INSERT [Junk [DT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\junk.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');

BULK INSERT [Scooters [DT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\scooters.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');

BULK INSERT [Areas [DT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\areas.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');

BULK INSERT [ScooterState [DT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\scooterState.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');

BULK INSERT [Rentals [FT]]] FROM 'C:\Users\szymo\Nextcloud\Studies\4th semester\Data warehouses\Lab\4 task\exampl\rentals.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', DATAFILETYPE = 'char', CODEPAGE = '65001');