use Scooters
GO

BULK INSERT Customers FROM 'D:\customers.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', CODEPAGE = 65001);

BULK INSERT dbo.Scooters FROM 'D:\scooters.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR = '|', CODEPAGE = 65001)

BULK INSERT dbo.Rentals_temp FROM 'D:\rentals.bulk' WITH (FIRSTROW = 2, FIELDTERMINATOR  ='|', CODEPAGE = 65001)

INSERT INTO dbo.Rentals (ID, city, start_timestamp, end_timestamp, travelled_distance, problem, phone_number, scooter_ID)
SELECT ID, city, DATEADD(SECOND, start_timestamp, '1970-01-01 00:00:00') AS start_timestamp, 
DATEADD(SECOND, end_timestamp, '1970-01-01 00:00:00') AS end_timestamp, travelled_distance, problem, phone_number, scooter_ID
FROM dbo.Rentals_temp

DROP TABLE IF EXISTS dbo.Rentals_temp;