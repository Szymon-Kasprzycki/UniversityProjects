--CREATE DATABASE SCOOTERS;

USE SCOOTERS;

CREATE TABLE Customers
   (phone_number                 NVARCHAR(13) NOT NULL PRIMARY KEY,
    name						 NVARCHAR(25) NOT NULL CHECK (name NOT LIKE '%[0-9]%'),
    surname  					 NVARCHAR(35) NOT NULL CHECK (surname NOT LIKE '%[0-9]%'),
	gender						 NVARCHAR(9) NOT NULL,
    email_address				 NVARCHAR(50) NOT NULL,
	birth_date     				 DATE NOT NULL);

CREATE TABLE Scooters
   (scooter_ID 					 INT NOT NULL PRIMARY KEY,
    Model 						 NVARCHAR(10) NOT NULL,
	Producer					 NVARCHAR(15) NOT NULL);
    
CREATE TABLE Rentals
   (ID     						 INT NOT NULL PRIMARY KEY,
    city                         NVARCHAR(15) NOT NULL CHECK (city NOT LIKE '%[0-9]%'),
    start_timestamp   	         DATETIME,
    end_timestamp   	         DATETIME,
	travelled_distance           DECIMAL(5,3),
	problem						 BIT NOT NULL DEFAULT 0,
	phone_number                 NVARCHAR(13) NOT NULL REFERENCES Customers,
	scooter_ID 					 INT NOT NULL REFERENCES Scooters);

CREATE TABLE Rentals_temp
   (ID     						 INT NOT NULL PRIMARY KEY,
    city                         NVARCHAR(15) NOT NULL CHECK (city NOT LIKE '%[0-9]%'),
    start_timestamp   	         FLOAT(4) NOT NULL,
    end_timestamp   	         FLOAT(4),
	travelled_distance           DECIMAL(5,3),
	problem						 BIT NOT NULL DEFAULT 0,
	phone_number                 NVARCHAR(13) NOT NULL REFERENCES Customers,
	scooter_ID 					 INT NOT NULL REFERENCES Scooters);

